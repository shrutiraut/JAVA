package com.cg.banking.beans;
import java.util.List;
import java.util.Map;
public class Customer {

	private int customerId;
	private String firstName,lastName,emailId,panCard,password;

	private Map<Integer,Account> account;


	private	List<Address> address;

}
