package com.cg.banking.beans;
public class Transaction {
	private int transactionId;
	private float amount;
	private String transactionType;
	
	
}
