package com.cg.payroll.services;

import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.beans.Employee;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
@Service("service")
@Transactional
public class PayrollServicesImpl implements PayrollServices {

	@Autowired
	PayrollDAOServices dao;
	
	@Override
	public int acceptEmployeeDetails(Employee employee)throws PayrollServicesDownException, SQLException, EmployeeDetailsNotFoundException {
		return dao.insertEmployee(calculateEmployeeNetSalary(employee));
	}

	
	@Override
	public List<Employee> getEmployeeDetails(int employeeid)throws EmployeeDetailsNotFoundException,PayrollServicesDownException, SQLException
	{
		return dao.getEmployee(employeeid);
	}

	@Override
	public List<Employee> getAllEmployeeDetails() throws PayrollServicesDownException, SQLException 
	{
		return dao.getAllEmployees();
	}

	@Override
	public void removeEmployee(int empId) throws SQLException {
		dao.deleteEmployee(empId);
		
	}


	@Override
	public Employee findEmployee(int id) {
		
		return dao.findEmployee(id);
	}


	@Override
	public void updateEmployee(Employee employee) throws SQLException, EmployeeDetailsNotFoundException, PayrollServicesDownException
	{
		employee = calculateEmployeeNetSalary(employee);
		dao.updateEmployee(employee);
		
	}
	
	public Employee calculateEmployeeNetSalary(Employee employee)
			throws EmployeeDetailsNotFoundException,
			PayrollServicesDownException, SQLException {

			
			Salary sal= employee.getSalary();
			sal.setHra((float)(sal.getBasicSalary()*0.4));
			sal.setTa((float)(sal.getBasicSalary()*0.2));
			sal.setDa((float)(sal.getBasicSalary()*0.24));
			sal.setGrossSalary(sal.getBasicSalary()+sal.getHra()+sal.getTa()+sal.getDa()+sal.getCompanyPf()+sal.getEmployeePf());
			float annSal=(float) (sal.getGrossSalary()*12);
			float annTax=0;
			float invest=employee.getYearlyInvestment();
			if(annSal<=250000){
			annTax=0;
			} else if((annSal>250000)&&(annSal<=500000)){

			if(invest<=150000){
			annTax=(float) ((annSal-250000-invest)*0.05);}
			else{
			annTax=(float) ((annSal-250000-150000)*0.05);
			}

			}else if ((annSal>500000)&&(annSal<=1000000)){

			if(invest<=150000){
			annTax=(float) ((250000-invest)*0.05+(annSal-500000)*0.10);
			} else{
			annTax=(float) ((250000-150000)*0.05+(annSal-500000)*0.10);
			}}
			else if((annSal>1000000)&&(annSal<=10000000)){

			if(invest<=150000){
			annTax=(float) ((250000-invest)*0.05+500000*0.10+(annSal-1000000)*0.30);
			} else{
			annTax=(float) ((250000-150000)*0.05+500000*0.10+(annSal-1000000)*0.30);
			}}
			else {

			if(invest<=150000){
			annTax=(float) ((250000-invest)*0.05+500000*0.10+(annSal-1000000)*0.30+annSal*0.02);}
			else{
			annTax=(float) ((250000-150000)*0.05+500000*0.10+(annSal-1000000)*0.30+annSal*0.02);
			}
			}
			sal.setMonthlyTax(annTax/12);
			sal.setNetSalary(sal.getGrossSalary()-sal.getMonthlyTax());
			employee.setSalary(sal);
			//pDao.updateEmployee(employee);
			return employee;

			}
	

}
